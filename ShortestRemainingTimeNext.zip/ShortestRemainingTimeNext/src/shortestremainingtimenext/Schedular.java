/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package shortestremainingtimenext;

import java.util.PriorityQueue;

/**
 *
 * @author Gimhani
 */
public class Schedular {
  PriorityQueue<Process> waitingQueue  =new PriorityQueue<Process>();
  PriorityQueue<Process> readyQueue  =new PriorityQueue<Process>();
  
  
  
  
  
  
  
}
